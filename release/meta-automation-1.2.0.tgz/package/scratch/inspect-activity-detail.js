const bm = require("../src/browser/browser-manager");

(async () => {
  const page = await bm.getThreadsPage();
  console.log("Navigating to https://www.threads.com/activity ...");
  await page.goto("https://www.threads.com/activity", { waitUntil: "domcontentloaded", timeout: 25000 });
  await new Promise(r => setTimeout(r, 2500));

  const items = await page.evaluate(() => {
    const listItems = Array.from(document.querySelectorAll('div[data-pressable-container="true"], a[href*="/post/"], div[role="listitem"]'));
    return listItems.slice(0, 10).map(it => {
      const link = it.tagName === "A" ? it : it.querySelector('a[href*="/post/"], a[href*="/@"]');
      const authorEl = it.querySelector('a[href*="/@"]') || link;
      const text = (it.innerText || "").replace(/\n/g, " | ");
      return {
        text: text.slice(0, 100),
        href: link?.href,
        author: authorEl?.innerText?.trim()
      };
    });
  });
  console.log("Activity items found:", JSON.stringify(items, null, 2));
  process.exit(0);
})();
