const bm = require("../src/browser/browser-manager");

(async () => {
  const page = await bm.getThreadsPage();
  console.log("Navigating to https://www.threads.com/messages ...");
  await page.goto("https://www.threads.com/messages", { waitUntil: "domcontentloaded", timeout: 25000 });
  await new Promise(r => setTimeout(r, 2500));

  const convs = await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('a[href*="/messages/t/"], div[data-pressable-container="true"]'));
    return items.slice(0, 5).map(it => {
      const a = it.tagName === "A" ? it : it.querySelector("a");
      return {
        text: (it.innerText || "").slice(0, 60).replace(/\n/g, " | "),
        href: a?.href
      };
    });
  });
  console.log("Found conversations:", convs);

  // Check if a chat textbox is already open or click the first conversation
  let hasInput = await page.$('div[role="textbox"][contenteditable="true"]');
  if (!hasInput && convs.length > 0 && convs[0].href) {
    console.log("Clicking first conversation:", convs[0].href);
    await page.evaluate(() => {
      const link = document.querySelector('a[href*="/messages/t/"]');
      if (link) link.click();
    });
    await new Promise(r => setTimeout(r, 2500));
    hasInput = await page.$('div[role="textbox"][contenteditable="true"]');
  }

  const chatInfo = await page.evaluate(() => {
    const tb = document.querySelector('div[role="textbox"][contenteditable="true"]');
    const sendBtns = Array.from(document.querySelectorAll('button, div[role="button"], svg')).map(b => {
      const aria = b.getAttribute("aria-label");
      const txt = (b.innerText || "").slice(0, 20);
      return { tag: b.tagName, aria, txt };
    }).filter(x => x.aria || x.txt);
    return {
      hasTextbox: !!tb,
      textboxAria: tb?.getAttribute("aria-label"),
      url: window.location.href,
      controls: sendBtns.slice(0, 15)
    };
  });
  console.log("Chat panel info:", JSON.stringify(chatInfo, null, 2));

  process.exit(0);
})();
