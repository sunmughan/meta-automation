const bm = require("../src/browser/browser-manager");

(async () => {
  const page = await bm.getThreadsPage();

  // 1. Navigate to main feed
  console.log("Navigating to https://www.threads.com/ ...");
  await page.goto("https://www.threads.com/", { waitUntil: "networkidle2", timeout: 25000 });
  await new Promise(r => setTimeout(r, 2000));

  // Inspect first article and its reply button
  const feedArticleInfo = await page.evaluate(() => {
    const articles = Array.from(document.querySelectorAll("article, div[data-pressable-container=\"true\"]"));
    if (articles.length === 0) return { error: "No articles found" };
    const first = articles[0];
    const svgs = Array.from(first.querySelectorAll("svg")).map(s => {
      const btn = s.closest("div[role=\"button\"], button") || s.parentElement;
      return {
        label: s.getAttribute("aria-label") || (btn ? btn.getAttribute("aria-label") : ""),
        d: s.querySelector("path")?.getAttribute("d")?.slice(0, 30),
        role: btn?.getAttribute("role"),
        tag: btn?.tagName
      };
    });
    return {
      totalArticles: articles.length,
      author: (first.innerText || "").split("\n")[0],
      snippet: (first.innerText || "").slice(0, 100),
      svgs
    };
  });
  console.log("Feed article info:", JSON.stringify(feedArticleInfo, null, 2));

  // 2. Click reply on first article and inspect the reply composer!
  console.log("Clicking reply button on first article...");
  const replyClickResult = await page.evaluate(() => {
    const articles = Array.from(document.querySelectorAll("article, div[data-pressable-container=\"true\"]"));
    if (articles.length === 0) return { success: false, reason: "No articles" };
    const first = articles[0];
    const svgs = Array.from(first.querySelectorAll("svg"));
    // The speech bubble / reply SVG
    const replySvg = svgs.find(s => {
      const aria = (s.getAttribute("aria-label") || "").toLowerCase();
      const parentAria = (s.closest("div[role=\"button\"], button")?.getAttribute("aria-label") || "").toLowerCase();
      const d = s.querySelector("path")?.getAttribute("d") || "";
      return aria.includes("reply") || parentAria.includes("reply") || d.includes("M1.75 14.5") || d.includes("M12 2C6.5");
    }) || svgs[1];

    if (!replySvg) return { success: false, reason: "No reply SVG found" };
    const btn = replySvg.closest("div[role=\"button\"], button") || replySvg;
    btn.click();
    return { success: true, aria: replySvg.getAttribute("aria-label") };
  });
  console.log("Reply click result:", replyClickResult);

  await new Promise(r => setTimeout(r, 2000));

  // Inspect the reply composer controls
  const replyComposerInfo = await page.evaluate(() => {
    const dialog = document.querySelector('div[role="dialog"], [aria-modal="true"]') || document.body;
    const isDialog = !!document.querySelector('div[role="dialog"], [aria-modal="true"]');
    const textboxes = Array.from(document.querySelectorAll('div[role="textbox"][contenteditable="true"]'));
    const allButtons = Array.from(dialog.querySelectorAll('button, div[role="button"]'));
    return {
      isDialog,
      textboxesCount: textboxes.length,
      buttons: allButtons.map(b => ({
        tag: b.tagName,
        aria: b.getAttribute("aria-label"),
        txt: (b.innerText || "").trim().slice(0, 30),
        disabled: b.getAttribute("aria-disabled") || b.disabled,
        classes: b.getAttribute("class")?.slice(0, 30),
        hasSvg: !!b.querySelector("svg"),
        svgAria: b.querySelector("svg")?.getAttribute("aria-label"),
        svgD: b.querySelector("svg path")?.getAttribute("d")?.slice(0, 30)
      }))
    };
  });
  console.log("Reply composer info:", JSON.stringify(replyComposerInfo, null, 2));

  // Press escape to close
  await page.keyboard.press("Escape");
  await new Promise(r => setTimeout(r, 1000));

  // 3. Inspect Activity page: https://www.threads.com/activity
  console.log("Navigating to https://www.threads.com/activity ...");
  await page.goto("https://www.threads.com/activity", { waitUntil: "domcontentloaded", timeout: 25000 });
  await new Promise(r => setTimeout(r, 2500));

  const activityInfo = await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('div[data-pressable-container="true"], article, div[role="listitem"]'));
    return {
      url: window.location.href,
      itemCount: items.length,
      sampleItems: items.slice(0, 5).map(it => ({
        text: (it.innerText || "").slice(0, 100).replace(/\n/g, " | "),
        links: Array.from(it.querySelectorAll("a")).map(a => a.href)
      }))
    };
  });
  console.log("Activity info:", JSON.stringify(activityInfo, null, 2));

  // 4. Inspect Messages page: https://www.threads.com/messages
  console.log("Navigating to https://www.threads.com/messages ...");
  await page.goto("https://www.threads.com/messages", { waitUntil: "domcontentloaded", timeout: 25000 });
  await new Promise(r => setTimeout(r, 2500));

  const messagesInfo = await page.evaluate(() => {
    const listItems = Array.from(document.querySelectorAll('div[data-pressable-container="true"], div[role="listitem"], a[href*="/messages/"]'));
    const conversationPanel = document.querySelector('div[role="textbox"]');
    return {
      url: window.location.href,
      conversationCount: listItems.length,
      sampleConversations: listItems.slice(0, 5).map(it => ({
        text: (it.innerText || "").slice(0, 80).replace(/\n/g, " | "),
        href: it.getAttribute("href") || it.querySelector("a")?.getAttribute("href")
      })),
      hasActiveChatTextbox: !!conversationPanel
    };
  });
  console.log("Messages info:", JSON.stringify(messagesInfo, null, 2));

  process.exit(0);
})();
