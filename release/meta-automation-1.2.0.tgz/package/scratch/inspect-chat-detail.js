const bm = require("../src/browser/browser-manager");

(async () => {
  const page = await bm.getThreadsPage();
  const detail = await page.evaluate(() => {
    const tb = document.querySelector('div[role="textbox"][contenteditable="true"]');
    const tbContainer = tb ? tb.parentElement : null;
    const parentBtns = tbContainer ? Array.from(tbContainer.parentElement.querySelectorAll('button, div[role="button"], svg')).map(el => ({
      tag: el.tagName,
      role: el.getAttribute("role"),
      aria: el.getAttribute("aria-label"),
      txt: el.innerText?.slice(0, 20),
      d: el.querySelector("path")?.getAttribute("d")?.slice(0, 25)
    })) : [];

    // Check message history bubbles
    const bubbles = Array.from(document.querySelectorAll('div[dir="auto"], span[dir="auto"], div[role="row"]')).map(b => (b.innerText || "").trim()).filter(t => t.length > 0 && t.length < 300);

    return {
      tbFound: !!tb,
      tbPlaceholder: tb?.getAttribute("data-placeholder") || tb?.getAttribute("placeholder") || tb?.innerText,
      parentBtns,
      recentBubbles: bubbles.slice(-10)
    };
  });
  console.log("Chat detail:", JSON.stringify(detail, null, 2));
  process.exit(0);
})();
