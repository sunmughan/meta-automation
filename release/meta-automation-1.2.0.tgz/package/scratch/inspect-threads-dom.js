const bm = require("../src/browser/browser-manager");

(async () => {
  const page = await bm.getThreadsPage();
  console.log("Current page URL:", page.url());

  // 1. Inspect "New thread" button on left sidebar or header
  const newThreadInfo = await page.evaluate(() => {
    const all = Array.from(document.querySelectorAll("svg, button, div[role=\"button\"], a"));
    const matches = all.filter(el => {
      const aria = (el.getAttribute("aria-label") || "").toLowerCase();
      const txt = (el.innerText || "").toLowerCase();
      return aria.includes("new thread") || txt.includes("new thread") || txt.includes("what's new");
    });
    return matches.map(m => ({
      tag: m.tagName,
      role: m.getAttribute("role"),
      aria: m.getAttribute("aria-label"),
      text: m.innerText?.trim()
    }));
  });
  console.log("New thread triggers found:", newThreadInfo);

  // 2. Open composer modal and inspect all buttons inside it
  console.log("Clicking New thread trigger to inspect composer...");
  await page.evaluate(() => {
    const btn = Array.from(document.querySelectorAll("div[role=\"button\"], button, svg")).find(el => {
      const aria = (el.getAttribute("aria-label") || "").toLowerCase();
      const txt = (el.innerText || "").toLowerCase();
      return aria === "new thread" || txt === "new thread";
    });
    if (btn) (btn.closest("div[role=\"button\"], button") || btn).click();
  });

  await new Promise(r => setTimeout(r, 2000));

  // Inspect composer dialog controls
  const composerControls = await page.evaluate(() => {
    const dialog = document.querySelector('div[role="dialog"], [aria-modal="true"]');
    if (!dialog) return { isModal: false, reason: "No dialog found" };
    const elements = Array.from(dialog.querySelectorAll('button, div[role="button"], svg, div[role="textbox"]'));
    return {
      isModal: true,
      dialogText: dialog.innerText.slice(0, 200),
      controls: elements.map(el => {
        const aria = el.getAttribute("aria-label");
        const txt = (el.innerText || "").trim().slice(0, 40);
        const role = el.getAttribute("role");
        const disabled = el.getAttribute("aria-disabled") || el.disabled;
        const classes = el.getAttribute("class");
        const svgPath = el.querySelector("path")?.getAttribute("d")?.slice(0, 30);
        return { tag: el.tagName, role, aria, txt, disabled, svgPath, classes: classes?.slice(0, 30) };
      })
    };
  });
  console.log("Composer controls:", JSON.stringify(composerControls, null, 2));

  // Close composer by pressing Escape
  await page.keyboard.press("Escape");
  await new Promise(r => setTimeout(r, 1000));

  // 3. Inspect feed article reply buttons
  const articleReplyControls = await page.evaluate(() => {
    const firstArticle = document.querySelector("article");
    if (!firstArticle) return "No article found";
    const svgsAndBtns = Array.from(firstArticle.querySelectorAll("svg, button, div[role=\"button\"]"));
    return svgsAndBtns.map(el => ({
      tag: el.tagName,
      role: el.getAttribute("role"),
      aria: el.getAttribute("aria-label"),
      txt: el.innerText?.trim()?.slice(0, 30),
      svgD: el.querySelector("path")?.getAttribute("d")?.slice(0, 30)
    }));
  });
  console.log("Article controls:", JSON.stringify(articleReplyControls, null, 2));

  process.exit(0);
})();
